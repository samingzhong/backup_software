#Change Log

## 0.2.0 (2017-05-16)

### Added
* Extensions have been added. Users should be able to perform extra behaviors depending on the apps installed on their machines. Currently, iTerm and Realm browser are supported.

### Changed
* Simulators with unavailable runtimes are not displayed.
* Simulators with no apps are not displayed.

### Fixed
* Fix an issue where checking exisiting startup items may crash the app.